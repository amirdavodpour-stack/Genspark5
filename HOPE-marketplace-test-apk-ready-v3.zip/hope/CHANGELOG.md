# Changelog

Condensed from the project's iterative build history. Entries are grouped
by theme rather than by round number.

## Backend: PostgreSQL migration

- Introduced a relational PostgreSQL schema (`backend/src/db.js`) alongside
  the original single-file JSON store, with a repository layer
  (`backend/src/repository.js`) that issues parameterized SQL with
  row-level locking for every state-changing action: registration, job
  create/publish/start/deliver/accept, offer create/accept, funding,
  payment release, refresh-token rotation, and password reset.
- Moved payment `createHold`/`releaseHold` onto a durable outbox
  (`backend/src/outbox_worker.js`): the funding/release transaction writes
  the outbox event atomically with the state change, so a worker crash
  mid-call cannot leave a payment stuck between states; failed events are
  retried instead of permanently stuck, and provider calls carry an
  explicit idempotency key.
- Removed an early PostgreSQL advisory single-writer lock in favor of
  row-level transaction locking, so multiple API replicas can mutate
  concurrently without corrupting shared state.
- **Fixed a remaining consistency gap**: several read paths (single-job
  detail, job create/publish/start/deliver/accept responses, payment
  views) still resolved the job's owner/provider/offer-count from the
  process-local in-memory cache even when `DATABASE_URL` was set, so a
  reply from one API replica could show `owner: null`/stale offer counts
  for data created on a different replica. `jobView`/`paymentView` in
  `backend/src/app.js` now resolve this through the same repository layer
  used everywhere else, and a related dead in-memory write (pushing every
  newly registered user into a cache array that was never read back,
  which grew unbounded for the life of the process) was removed.

## Backend: security & correctness

- Switched password hashing from synchronous to asynchronous PBKDF2 so a
  login/register call no longer blocks the event loop for the duration of
  the hash; bounded the accepted iteration count on stored hashes.
- Fixed `enforceJobState` calling the wrong helper (a state-*transition*
  check instead of a current-state membership check), which had been
  rejecting nearly every legitimate lifecycle action (publish, offer
  accept, start, deliver, evidence, release) with `409 INVALID_STATE`.
- Reordered the payment-funding idempotency check to run before the job
  state guard, so a retried request with the same `Idempotency-Key`
  returns the original payment instead of a spurious 409.
- Required a user-bound, expiring upload intent for direct-to-S3 uploads,
  consumed on completion; added file-signature validation (not just
  declared content-type) for both direct and proxied uploads.
- Enforced production-only invariants at boot: real token secrets,
  `DATABASE_URL`, HTTPS `PUBLIC_BASE_URL`, explicit CORS origins,
  `STORAGE_BACKEND=s3`, and webhook-based password-reset delivery.

## Mobile (Flutter)

- Fixed a spurious `Navigator.pop()` assertion after login (the login
  page is the router's `home`, never pushed).
- Added an `onUnauthorized` hook plus an actual access-token refresh flow
  in `ApiClient` (request retried once after a silent refresh; falls back
  to logout only if the refresh itself fails).
- Wired evidence uploads through the existing retry queue (previously
  instantiated but never called, so uploads had no retry despite the UI
  implying one).
- Made the home tab bar lazily build each tab on first visit instead of
  eagerly constructing all four, and removed a duplicate embedded jobs
  list that had been firing `GET /jobs` twice on every login.
- Added client-side validation for job creation (required fields,
  description length, numeric/positive budgets and duration, budget
  ordering) so invalid input is caught before an API call.
- Fixed the Android adaptive launcher icon (was a raw vector, not
  wrapped in an `<adaptive-icon>`) and removed an unreferenced duplicate
  icon.

## Known limitations (current)

- Payments are simulated end-to-end (`PAYMENT_PROVIDER=simulator`); no
  real payment-service-provider integration exists yet.
- There is no admin surface; categories are seed-only.
