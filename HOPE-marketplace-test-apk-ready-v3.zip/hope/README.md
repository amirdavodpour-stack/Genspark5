# HOPE Marketplace

A two-sided work marketplace: buyers post jobs, providers submit offers,
and a payment-hold/release flow settles the job once evidence is accepted.

- `backend/` — Node.js HTTP API (no framework), PostgreSQL-backed in
  production, JSON-file-backed for local development. See
  `backend/README.md`.
- `lib/` — Flutter mobile client (RTL, Material 3).
- `android/` — Android build configuration for the Flutter app.
- `test/`, `integration_test/` — Flutter unit/widget/integration tests.
- `tools/` — release helper scripts (`build_apk_release.sh`,
  `static_audit.sh`).
- `data/` — local JSON datastore used by the backend when `DATABASE_URL`
  is not set.

## What's implemented

**Backend routes** (`backend/src/app.js`): auth (register, login, logout,
refresh, password-reset request/confirm), provider profile, categories,
jobs (create, publish, list, detail, "mine"), offers (create, accept),
job execution transitions (start, deliver, accept-delivery, evidence),
payments (fund, release, status), and file upload (multipart, presigned
S3, and completion-verified direct upload).

**Mobile app** (`lib/`): guest browsing, login/register/password reset,
job listing/detail/create, offers, the full transaction lifecycle UI
(fund → start → evidence → deliver → accept → settlement), profile,
secure token storage with automatic access-token refresh, and an upload
retry queue.

There is no separate web client or admin dashboard in this repository —
if you've seen a feature list claiming otherwise, it described a planned
scope, not what's built.

## Not implemented / known limitations

- **Payments are simulated.** `PAYMENT_PROVIDER=simulator` is the only
  supported provider (`backend/src/payment_provider.js`); no real money
  moves. A real payment-service-provider adapter is required before this
  can process live transactions.
- **No admin surface.** Categories are seeded once at startup; there is
  no endpoint to manage users, disputes, or moderation.

## Quick start

Backend:

```bash
cd backend
cp .env.example .env
node src/migrate.js
node src/server.js
```

Mobile app, pointed at a local backend on an Android emulator:

```bash
flutter pub get
flutter run --dart-define=API_BASE_URL=http://10.0.2.2:3000/api/v1
```

Release APK:

```bash
flutter build apk --release --dart-define=API_BASE_URL=https://YOUR_API_HOST/api/v1
```

Build/signing details, including the Flutter/Android toolchain versions
this repo targets, are in `android/ANDROID-CONFIG.md`,
`android/README-API-CONFIG.md`, and `tools/build_apk_release.sh`.
Production release signing is intentionally fail-closed: this repository
does not contain a production keystore, and pilot/local builds made with
a non-production keystore must never be treated as store-ready
artifacts.

## Project history

See `CHANGELOG.md` for a condensed history of major changes. Operational references: `SECURITY-THREAT-MODEL.md`, `AUTHORIZATION-MATRIX.md`,
`DISASTER-RECOVERY.md`, and `RELEASE-CHECKLIST.md`.

## CI / APK builds

This repository intentionally contains no `.github/workflows` build pipeline.
APK builds are handled by an external Universal Flutter APK Builder so the
project's own workflow files cannot interfere with release builds. The builder
auto-detects the Flutter project, Android/Gradle layout, Flutter version, and
APK output path.
