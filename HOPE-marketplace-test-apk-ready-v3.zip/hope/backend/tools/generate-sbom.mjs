#!/usr/bin/env node
// Regenerates sbom.json (CycloneDX 1.5) from package.json's *direct*
// dependencies. This is a deliberately dependency-free generator (only
// node:fs/node:crypto) so it always runs, even offline or before `npm ci`.
//
// LIMITATION: this only lists direct dependencies, not the full transitive
// tree (pg/@aws-sdk pull in their own sub-dependencies). Once real network
// access is available, prefer a real SBOM tool for a complete tree, e.g.:
//   npx @cyclonedx/cyclonedx-npm --output-file sbom.json
// Run `npm run sbom` (this script) as a fast, offline-safe fallback/check
// in CI even when the full tool also runs, since it costs nothing and
// catches "package.json changed but sbom.json wasn't regenerated" drift.
import fs from 'node:fs';
import crypto from 'node:crypto';

const pkg = JSON.parse(fs.readFileSync(new URL('../package.json', import.meta.url), 'utf8'));
const stripRange = (v) => v.replace(/^[\^~]/, '');

const componentsOf = (deps, scope) => Object.entries(deps || {}).map(([name, version]) => ({
  type: 'library',
  name,
  version: stripRange(version),
  purl: `pkg:npm/${encodeURIComponent(name)}@${stripRange(version)}`,
  scope,
}));

const sbom = {
  bomFormat: 'CycloneDX',
  specVersion: '1.5',
  serialNumber: `urn:uuid:${crypto.randomUUID()}`,
  version: 1,
  metadata: {
    timestamp: new Date().toISOString(),
    component: { type: 'application', name: pkg.name, version: pkg.version },
  },
  components: [
    ...componentsOf(pkg.dependencies, 'required'),
    ...componentsOf(pkg.devDependencies, 'optional'),
  ],
};

fs.writeFileSync(new URL('../sbom.json', import.meta.url), JSON.stringify(sbom, null, 2) + '\n');
console.log(`sbom.json written: ${sbom.components.length} direct component(s).`);
